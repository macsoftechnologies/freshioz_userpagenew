import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Building2, 
  Coins, 
  ArrowUpRight, 
  CheckCircle2, 
  Clock, 
  ShieldCheck, 
  CreditCard, 
  FileText, 
  LogOut, 
  AlertCircle,
  TrendingUp,
  X
} from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { saveFreshiozStore } from '../shared/freshiozStore';
import FreshiozLogo from '../components/common/FreshiozLogo';

export default function SocietyPartnerPortalPage() {
  const { 
    store, 
    approvedSocieties, 
    partnerAuth, 
    loginPartner, 
    logoutPartner,
    activeUser,
    logoutUser
  } = useStore();

  // Login Form States
  const [selectedSocietyId, setSelectedSocietyId] = useState(approvedSocieties[0]?.id || 'soc-1');
  const [headPhone, setHeadPhone] = useState('9876543210');
  const [otp, setOtp] = useState(['1', '2', '3', '4']);
  const [loginStep, setLoginStep] = useState('CREDENTIALS'); // 'CREDENTIALS' -> 'OTP'
  const [loginError, setLoginError] = useState('');

  // Withdrawal Modal State
  const [isWithdrawModalOpen, setIsWithdrawModalOpen] = useState(false);
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawMsg, setWithdrawMsg] = useState('');

  const currentSociety = store.societies.find(s => s.id === (partnerAuth?.societyId || selectedSocietyId)) || store.societies[0];

  // Quick Demo Auto-fill
  const handleAutoFillDemo = () => {
    setSelectedSocietyId('soc-1');
    setHeadPhone('9876543210');
    setLoginError('');
    setLoginStep('OTP');
  };

  const handleCredentialsSubmit = (e) => {
    e.preventDefault();
    const enteredDigits = headPhone.replace(/\D/g, '').slice(-10);
    const registeredDigits = (currentSociety.secretaryPhone || '').replace(/\D/g, '').slice(-10);

    if (!enteredDigits) {
      setLoginError('Please enter the registered Secretary / Warden phone number.');
      return;
    }

    if (enteredDigits !== registeredDigits) {
      setLoginError(`Phone +91 ${headPhone} does not match the registered Secretary phone (+91 ******${registeredDigits.slice(-4)}) on file for ${currentSociety.name}.`);
      return;
    }

    setLoginError('');
    setLoginStep('OTP');
  };

  const handleOtpVerify = (e) => {
    e.preventDefault();
    const entered = otp.join('');
    if (entered !== '1234') {
      setLoginError('Invalid OTP. Use 1234 for testing.');
      return;
    }

    const authPayload = {
      societyId: currentSociety.id,
      societyName: currentSociety.name,
      secretaryName: currentSociety.secretaryName,
      phone: headPhone
    };
    loginPartner(authPayload);
    setLoginStep('CREDENTIALS');
  };

  const handleLogout = () => {
    logoutPartner();
  };

  // Submit Withdrawal Request
  const handleWithdrawSubmit = (e) => {
    e.preventDefault();
    const amt = Number(withdrawAmount);
    if (!amt || amt <= 0) {
      setWithdrawMsg('Please enter a valid amount.');
      return;
    }
    if (amt > currentSociety.balanceEarned) {
      setWithdrawMsg(`Requested amount cannot exceed your available balance of ₹${currentSociety.balanceEarned.toLocaleString()}.`);
      return;
    }

    const newWithdrawal = {
      id: `WDR-${Date.now().toString().slice(-4)}`,
      societyId: currentSociety.id,
      societyName: currentSociety.name,
      amount: amt,
      bankDetails: `${currentSociety.bankDetails?.bankName} - A/C ...${currentSociety.bankDetails?.accountNumber?.slice(-4)} (IFSC: ${currentSociety.bankDetails?.ifscCode})`,
      requestedAt: new Date().toISOString(),
      status: 'PENDING_APPROVAL',
      bankUtr: null,
      disbursedAt: null
    };

    saveFreshiozStore(prev => {
      const updatedSocieties = prev.societies.map(s => {
        if (s.id === currentSociety.id) {
          return {
            ...s,
            balanceEarned: Number((s.balanceEarned - amt).toFixed(2))
          };
        }
        return s;
      });

      return {
        ...prev,
        societies: updatedSocieties,
        withdrawals: [newWithdrawal, ...(prev.withdrawals || [])]
      };
    });

    setIsWithdrawModalOpen(false);
    setWithdrawAmount('');
    alert(`Withdrawal request of ₹${amt.toLocaleString()} submitted successfully! It has been deducted from your available balance and sent to Admin for bank transfer.`);
  };

  // Society-specific ledger
  const societyWithdrawals = (store.withdrawals || []).filter(w => w.societyId === currentSociety?.id);
  const societyOrders = (store.orders || []).filter(o => o.societyId === currentSociety?.id);

  // If Logged in as Resident User, DO NOT show Association Partner Login form!
  if (activeUser) {
    return (
      <div style={{ maxWidth: '520px', margin: '48px auto', padding: '0 16px', textAlign: 'center' }}>
        <div style={{
          background: '#FFFFFF',
          borderRadius: '22px',
          border: '1.5px solid #E5ECE7',
          padding: '36px 28px',
          boxShadow: '0 8px 24px rgba(21, 34, 27, 0.06)'
        }}>
          <div style={{
            width: '64px',
            height: '64px',
            borderRadius: '50%',
            background: '#F0F4F2',
            color: '#234B3C',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            margin: '0 auto 16px'
          }}>
            <Building2 size={30} />
          </div>

          <div style={{
            display: 'inline-block',
            background: '#FFF8ED',
            color: '#B45309',
            fontSize: '11px',
            fontWeight: 800,
            padding: '4px 12px',
            borderRadius: '9999px',
            letterSpacing: '0.4px',
            textTransform: 'uppercase',
            marginBottom: '10px'
          }}>
            Apartment & Hostel Partner Desk
          </div>

          <h2 style={{ fontSize: '21px', fontWeight: 800, color: '#15221B', marginBottom: '8px' }}>
            Restricted to Society Representatives
          </h2>

          <p style={{ fontSize: '13.5px', color: '#52635A', lineHeight: '1.55', marginBottom: '24px' }}>
            You are currently signed in as Resident: <strong>{activeUser.name}</strong> ({activeUser.societyName}).
            <br />
            This desk is exclusively for Apartment Association Presidents, Secretaries, and Wardens to manage community earnings & withdrawals.
          </p>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            <Link
              to="/"
              style={{
                display: 'block',
                background: '#234B3C',
                color: '#FFF',
                padding: '11px 24px',
                borderRadius: '9999px',
                fontWeight: 700,
                fontSize: '13.5px',
                textDecoration: 'none'
              }}
            >
              Return to Farm Produce Store
            </Link>

            <button
              type="button"
              onClick={() => logoutUser()}
              style={{
                background: '#FFF1F2',
                color: '#E11D48',
                border: '1.5px solid #FFE4E6',
                padding: '10px 20px',
                borderRadius: '9999px',
                fontWeight: 700,
                fontSize: '13px',
                cursor: 'pointer'
              }}
            >
              Sign Out Resident Account to Login as Partner
            </button>
          </div>
        </div>
      </div>
    );
  }

  // If NOT Logged In, Render Dedicated Society Partner Login Screen
  if (!partnerAuth) {
    return (
      <div style={{ maxWidth: '480px', margin: '40px auto', padding: '0 16px' }}>
        <div style={{
          background: '#FFFFFF',
          borderRadius: '20px',
          border: '1.5px solid #E5ECE7',
          padding: '32px 24px',
          boxShadow: '0 8px 24px rgba(21, 34, 27, 0.08)'
        }}>
          <div style={{ textAlign: 'center', marginBottom: '24px' }}>
            <FreshiozLogo height={42} showTagline={false} />
            <div style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '6px',
              background: '#FEF7ED',
              border: '1px solid #FCD34D',
              color: '#B45309',
              padding: '4px 12px',
              borderRadius: '9999px',
              fontSize: '11px',
              fontWeight: 800,
              marginTop: '12px'
            }}>
              <Coins size={13} />
              <span>SOCIETY & HOSTEL PARTNER PORTAL</span>
            </div>
            <h2 style={{ fontSize: '22px', marginTop: '10px', color: '#234B3C' }}>
              Association Partner Login
            </h2>
            <p style={{ fontSize: '13px', color: '#52635A', marginTop: '4px' }}>
              For Apartment Presidents, Secretaries, and Hostel Wardens to manage community earnings & withdrawals.
            </p>
          </div>

          {loginError && (
            <div style={{
              background: '#FEE2E2',
              border: '1px solid #FCA5A5',
              color: '#B91C1C',
              padding: '10px 14px',
              borderRadius: '10px',
              fontSize: '13px',
              marginBottom: '16px'
            }}>
              {loginError}
            </div>
          )}

          {loginStep === 'CREDENTIALS' ? (
            <form onSubmit={handleCredentialsSubmit}>
              {/* Select Apartment or Hostel */}
              <div className="form-group-field">
                <label className="form-label-title">Select Your Society or Hostel</label>
                <select
                  className="form-input-control"
                  value={selectedSocietyId}
                  onChange={(e) => setSelectedSocietyId(e.target.value)}
                  style={{ cursor: 'pointer' }}
                >
                  {approvedSocieties.map(soc => (
                    <option key={soc.id} value={soc.id}>
                      {soc.name} ({soc.type === 'HOSTEL' ? 'Hostel' : 'Apartment'})
                    </option>
                  ))}
                </select>
              </div>

              {/* Head / Secretary Registered Phone */}
              <div className="form-group-field">
                <label className="form-label-title">Secretary / Warden Phone Number</label>
                <input
                  type="tel"
                  className="form-input-control"
                  placeholder="Registered phone number"
                  value={headPhone}
                  onChange={(e) => setHeadPhone(e.target.value)}
                  required
                />
              </div>

              {/* Quick Auto Fill Button for Demo Testing */}
              <div style={{ marginBottom: '18px' }}>
                <button
                  type="button"
                  onClick={handleAutoFillDemo}
                  style={{
                    width: '100%',
                    background: '#F0F4F2',
                    border: '1px dashed #234B3C',
                    color: '#234B3C',
                    padding: '8px 12px',
                    borderRadius: '8px',
                    fontSize: '12px',
                    fontWeight: 700,
                    cursor: 'pointer'
                  }}
                >
                  ⚡ One-Click Demo: Greenfield Heights Association
                </button>
              </div>

              <button
                type="submit"
                style={{
                  width: '100%',
                  background: '#234B3C',
                  color: '#FFF',
                  fontWeight: 700,
                  fontSize: '15px',
                  padding: '13px',
                  borderRadius: '9999px',
                  boxShadow: '0 4px 12px rgba(35, 75, 60, 0.25)'
                }}
              >
                Send 4-Digit OTP
              </button>
            </form>
          ) : (
            <form onSubmit={handleOtpVerify}>
              <div style={{
                background: '#EBF2EE',
                borderRadius: '12px',
                padding: '12px',
                fontSize: '13px',
                color: '#234B3C',
                textAlign: 'center',
                marginBottom: '16px'
              }}>
                ✨ Test OTP Active: <strong>1234</strong>
              </div>

              <div className="otp-box-row">
                {otp.map((digit, idx) => (
                  <input
                    key={idx}
                    type="text"
                    maxLength={1}
                    className="otp-digit-input"
                    value={digit}
                    onChange={(e) => {
                      const val = e.target.value.replace(/[^0-9]/g, '');
                      const newOtp = [...otp];
                      newOtp[idx] = val;
                      setOtp(newOtp);
                    }}
                  />
                ))}
              </div>

              <div style={{ display: 'flex', gap: '10px', marginTop: '20px' }}>
                <button
                  type="button"
                  onClick={() => setLoginStep('CREDENTIALS')}
                  style={{
                    flex: 1,
                    background: '#F0F4F2',
                    color: '#52635A',
                    fontWeight: 700,
                    fontSize: '14px',
                    padding: '12px',
                    borderRadius: '9999px'
                  }}
                >
                  Back
                </button>
                <button
                  type="submit"
                  style={{
                    flex: 2,
                    background: '#F28E14',
                    color: '#FFF',
                    fontWeight: 700,
                    fontSize: '14px',
                    padding: '12px',
                    borderRadius: '9999px'
                  }}
                >
                  Login to Partner Desk
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    );
  }

  // LOGGED IN: Dedicated Society Partner Dashboard
  return (
    <div className="section-container" style={{ paddingTop: '20px' }}>
      {/* Top Header Card */}
      <div style={{
        background: '#FFFFFF',
        borderRadius: '20px',
        border: '1.5px solid #E5ECE7',
        padding: '24px 28px',
        marginBottom: '24px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '16px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <div style={{
            width: '54px',
            height: '54px',
            borderRadius: '16px',
            background: '#234B3C',
            color: '#FFF',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}>
            <Building2 size={28} />
          </div>

          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <h1 style={{ fontSize: '22px', color: '#15221B' }}>{currentSociety.name}</h1>
              <span style={{ background: '#EBF7E5', color: '#234B3C', fontSize: '11px', fontWeight: 800, padding: '2px 8px', borderRadius: '9999px' }}>
                {currentSociety.type === 'HOSTEL' ? 'HOSTEL' : 'APARTMENT'}
              </span>
            </div>
            <div style={{ fontSize: '13px', color: '#52635A', marginTop: '2px' }}>
              {currentSociety.address} • Authorized Head: <strong>{currentSociety.secretaryName}</strong>
            </div>
          </div>
        </div>

        <button
          type="button"
          onClick={handleLogout}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            padding: '8px 16px',
            borderRadius: '9999px',
            background: '#F0F4F2',
            color: '#52635A',
            fontSize: '13px',
            fontWeight: 700
          }}
        >
          <LogOut size={15} />
          <span>Logout Partner Desk</span>
        </button>
      </div>

      {/* 3 Metrics Cards */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))',
        gap: '20px',
        marginBottom: '28px'
      }}>
        {/* 1. Available Earnings Balance with Withdraw Action */}
        <div style={{
          background: 'linear-gradient(135deg, #234B3C 0%, #173328 100%)',
          borderRadius: '18px',
          padding: '24px',
          color: '#FFFFFF',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'space-between',
          gap: '16px'
        }}>
          <div>
            <div style={{ fontSize: '12.5px', color: '#C3E6B4', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.6px' }}>
              Available Withdrawable Balance
            </div>
            <div style={{ fontSize: '36px', fontWeight: 800, fontFamily: 'Outfit', color: '#FFFFFF', marginTop: '4px' }}>
              ₹{currentSociety.balanceEarned?.toLocaleString() || '0'}
            </div>
            <div style={{ fontSize: '12px', color: '#D2E2D8', marginTop: '4px' }}>
              Accumulated cashback pool from resident orders
            </div>
          </div>

          <button
            type="button"
            onClick={() => setIsWithdrawModalOpen(true)}
            style={{
              background: '#F28E14',
              color: '#FFF',
              fontWeight: 700,
              fontSize: '14px',
              padding: '11px 20px',
              borderRadius: '9999px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '8px',
              boxShadow: '0 4px 12px rgba(242, 142, 20, 0.4)'
            }}
          >
            <ArrowUpRight size={17} />
            <span>Request Bank Withdrawal</span>
          </button>
        </div>

        {/* 2. Total Orders Delivered */}
        <div style={{
          background: '#FFFFFF',
          borderRadius: '18px',
          border: '1.5px solid #E5ECE7',
          padding: '24px',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'space-between'
        }}>
          <div>
            <div style={{ fontSize: '12px', color: '#83968D', fontWeight: 700, textTransform: 'uppercase' }}>
              Resident Orders Delivered
            </div>
            <div style={{ fontSize: '36px', fontWeight: 800, fontFamily: 'Outfit', color: '#234B3C', marginTop: '4px' }}>
              {currentSociety.totalOrdersDelivered || 0}
            </div>
            <div style={{ fontSize: '12.5px', color: '#52635A', marginTop: '4px' }}>
              Across {currentSociety.totalUnits} flats & rooms
            </div>
          </div>

          <div style={{ fontSize: '12px', color: '#78B159', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '4px' }}>
            <TrendingUp size={15} /> Growing community participation
          </div>
        </div>

        {/* 3. Society Cashback Model */}
        <div style={{
          background: '#FFFFFF',
          borderRadius: '18px',
          border: '1.5px solid #E5ECE7',
          padding: '24px',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'space-between'
        }}>
          <div>
            <div style={{ fontSize: '12px', color: '#83968D', fontWeight: 700, textTransform: 'uppercase' }}>
              Active Commission Rate
            </div>
            <div style={{ fontSize: '32px', fontWeight: 800, fontFamily: 'Outfit', color: '#DE8821', marginTop: '4px' }}>
              {currentSociety.commissionType === 'PERCENTAGE'
                ? `${currentSociety.commissionValue}%`
                : `₹${currentSociety.commissionValue} / Order`}
            </div>
            <div style={{ fontSize: '12.5px', color: '#52635A', marginTop: '4px' }}>
              Directly credited to society account on next-day delivery
            </div>
          </div>

          <div style={{ fontSize: '12px', color: '#234B3C', fontWeight: 600 }}>
            Setup by Freshioz Admin Verification Desk
          </div>
        </div>
      </div>

      {/* Verified Bank Account Details Card */}
      <div style={{
        background: '#FAFBFB',
        borderRadius: '18px',
        border: '1.5px solid #E5ECE7',
        padding: '24px',
        marginBottom: '28px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '16px' }}>
          <CreditCard size={20} color="#234B3C" />
          <h3 style={{ fontSize: '18px', color: '#15221B' }}>Registered Settlement Bank Account</h3>
          <span style={{ background: '#EBF7E5', color: '#234B3C', fontSize: '11.5px', fontWeight: 700, padding: '3px 10px', borderRadius: '9999px', display: 'flex', alignItems: 'center', gap: '4px' }}>
            <CheckCircle2 size={13} color="#78B159" /> Verified for Disbursal
          </span>
        </div>

        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
          gap: '16px'
        }}>
          <div>
            <div style={{ fontSize: '11.5px', color: '#83968D', fontWeight: 600 }}>Bank Name</div>
            <div style={{ fontSize: '15px', fontWeight: 700, color: '#15221B' }}>
              {currentSociety.bankDetails?.bankName || 'HDFC Bank'}
            </div>
          </div>

          <div>
            <div style={{ fontSize: '11.5px', color: '#83968D', fontWeight: 600 }}>Account Holder</div>
            <div style={{ fontSize: '15px', fontWeight: 700, color: '#15221B' }}>
              {currentSociety.bankDetails?.accountHolder || currentSociety.name}
            </div>
          </div>

          <div>
            <div style={{ fontSize: '11.5px', color: '#83968D', fontWeight: 600 }}>Account Number</div>
            <div style={{ fontSize: '15px', fontWeight: 700, color: '#15221B', fontFamily: 'monospace' }}>
              {currentSociety.bankDetails?.accountNumber || '50100492817291'}
            </div>
          </div>

          <div>
            <div style={{ fontSize: '11.5px', color: '#83968D', fontWeight: 600 }}>IFSC Code</div>
            <div style={{ fontSize: '15px', fontWeight: 700, color: '#15221B', fontFamily: 'monospace' }}>
              {currentSociety.bankDetails?.ifscCode || 'HDFC0001742'}
            </div>
          </div>
        </div>
      </div>

      {/* Transaction & Withdrawal History Ledger */}
      <div style={{
        background: '#FFFFFF',
        borderRadius: '18px',
        border: '1.5px solid #E5ECE7',
        padding: '24px',
        marginBottom: '40px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '18px', flexWrap: 'wrap', gap: '8px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <FileText size={18} color="#234B3C" />
            <h3 style={{ fontSize: '18px', color: '#15221B' }}>Withdrawal Requests & Payout Ledger</h3>
          </div>
          <span style={{ fontSize: '12px', color: '#83968D' }}>
            Transfers are processed directly via NEFT/IMPS
          </span>
        </div>

        {societyWithdrawals.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '36px', color: '#83968D', fontSize: '13.5px' }}>
            No withdrawal requests submitted yet. Use the "Request Bank Withdrawal" button above when ready.
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {societyWithdrawals.map(w => (
              <div
                key={w.id}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  padding: '14px 18px',
                  borderRadius: '12px',
                  background: '#FAFBFB',
                  border: '1px solid #E5ECE7',
                  flexWrap: 'wrap',
                  gap: '12px'
                }}
              >
                <div>
                  <div style={{ fontWeight: 700, fontSize: '14px', color: '#15221B' }}>
                    Payout ID: {w.id}
                  </div>
                  <div style={{ fontSize: '12px', color: '#52635A', marginTop: '2px' }}>
                    {new Date(w.requestedAt).toLocaleString('en-IN')} • {w.bankDetails}
                  </div>
                  {w.bankUtr && (
                    <div style={{ fontSize: '11.5px', color: '#234B3C', fontWeight: 700, marginTop: '2px' }}>
                      Bank UTR: {w.bankUtr}
                    </div>
                  )}
                  {w.rejectionReason && (
                    <div style={{ fontSize: '11.5px', color: '#DC2626', marginTop: '2px', fontWeight: 600 }}>
                      Rejection Reason: {w.rejectionReason} (Amount has been refunded to your wallet)
                    </div>
                  )}
                </div>

                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontSize: '16px', fontWeight: 800, color: w.status === 'REJECTED' ? '#DC2626' : '#234B3C' }}>
                    {w.status === 'REJECTED' ? `+₹${w.amount.toLocaleString()} (Refunded)` : `-₹${w.amount.toLocaleString()}`}
                  </div>
                  <div style={{ marginTop: '4px' }}>
                    {w.status === 'COMPLETED' ? (
                      <span style={{ background: '#EBF7E5', color: '#234B3C', padding: '3px 10px', borderRadius: '9999px', fontSize: '11px', fontWeight: 800 }}>
                        ✓ TRANSFERRED
                      </span>
                    ) : w.status === 'REJECTED' ? (
                      <span style={{ background: '#FEE2E2', color: '#DC2626', padding: '3px 10px', borderRadius: '9999px', fontSize: '11px', fontWeight: 800 }}>
                        ✕ REJECTED & REFUNDED
                      </span>
                    ) : (
                      <span style={{ background: '#FEF3C7', color: '#B45309', padding: '3px 10px', borderRadius: '9999px', fontSize: '11px', fontWeight: 800 }}>
                        ⏳ PENDING ADMIN TRANSFER
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Withdrawal Request Modal */}
      {isWithdrawModalOpen && (
        <div className="modal-backdrop-overlay" onClick={() => setIsWithdrawModalOpen(false)}>
          <div className="modal-dialog-box" onClick={(e) => e.stopPropagation()}>
            <button
              type="button"
              className="modal-close-icon"
              onClick={() => setIsWithdrawModalOpen(false)}
            >
              <X size={18} />
            </button>

            <div style={{ textAlign: 'center', marginBottom: '20px' }}>
              <div style={{ width: '48px', height: '48px', borderRadius: '50%', background: '#FEF7ED', color: '#DE8821', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 10px' }}>
                <Coins size={24} />
              </div>
              <h3 style={{ fontSize: '20px', color: '#234B3C' }}>Request Bank Withdrawal</h3>
              <p style={{ fontSize: '13px', color: '#52635A', marginTop: '4px' }}>
                Transfer accumulated society earnings to your registered bank account.
              </p>
            </div>

            {withdrawMsg && (
              <div style={{
                background: '#FEE2E2',
                border: '1px solid #FCA5A5',
                color: '#B91C1C',
                padding: '10px 14px',
                borderRadius: '10px',
                fontSize: '13px',
                marginBottom: '16px'
              }}>
                {withdrawMsg}
              </div>
            )}

            <form onSubmit={handleWithdrawSubmit}>
              <div style={{
                background: '#EBF2EE',
                borderRadius: '12px',
                padding: '14px',
                marginBottom: '16px',
                fontSize: '13px',
                color: '#234B3C'
              }}>
                <div>Available Balance: <strong>₹{currentSociety.balanceEarned?.toLocaleString()}</strong></div>
                <div style={{ fontSize: '12px', color: '#52635A', marginTop: '4px' }}>
                  Target Bank: {currentSociety.bankDetails?.bankName} (A/C ...{currentSociety.bankDetails?.accountNumber?.slice(-4)})
                </div>
              </div>

              <div className="form-group-field">
                <label className="form-label-title">Enter Withdrawal Amount (₹)</label>
                <input
                  type="number"
                  className="form-input-control"
                  placeholder="e.g. 5000"
                  value={withdrawAmount}
                  onChange={(e) => setWithdrawAmount(e.target.value)}
                  max={currentSociety.balanceEarned}
                  required
                />
              </div>

              <div style={{ display: 'flex', gap: '8px', marginBottom: '20px' }}>
                <button
                  type="button"
                  onClick={() => setWithdrawAmount(String(Math.min(2500, currentSociety.balanceEarned)))}
                  style={{ flex: 1, padding: '6px', background: '#F0F4F2', borderRadius: '6px', fontSize: '12px', fontWeight: 600 }}
                >
                  ₹2,500
                </button>
                <button
                  type="button"
                  onClick={() => setWithdrawAmount(String(Math.min(5000, currentSociety.balanceEarned)))}
                  style={{ flex: 1, padding: '6px', background: '#F0F4F2', borderRadius: '6px', fontSize: '12px', fontWeight: 600 }}
                >
                  ₹5,000
                </button>
                <button
                  type="button"
                  onClick={() => setWithdrawAmount(String(currentSociety.balanceEarned))}
                  style={{ flex: 1, padding: '6px', background: '#F0F4F2', borderRadius: '6px', fontSize: '12px', fontWeight: 600 }}
                >
                  Full Balance
                </button>
              </div>

              <button
                type="submit"
                style={{
                  width: '100%',
                  background: '#234B3C',
                  color: '#FFF',
                  fontWeight: 700,
                  fontSize: '15px',
                  padding: '13px',
                  borderRadius: '9999px',
                  boxShadow: '0 4px 12px rgba(35, 75, 60, 0.25)'
                }}
              >
                Confirm & Submit Payout Request
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
