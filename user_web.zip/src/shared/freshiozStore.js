// Freshioz Unified Shared Reactive Data Store for Admin Portal & User Web
// Synchronizes seamlessly with localStorage and dispatches window events for multi-tab sync

import {
  INITIAL_WAREHOUSES,
  INITIAL_SHOPS,
  INITIAL_EMPLOYEES,
  INITIAL_SOCIETIES,
  INITIAL_CATEGORIES,
  INITIAL_UNITS,
  INITIAL_PRODUCTS,
  INITIAL_ORDERS,
  INITIAL_WITHDRAWALS,
  INITIAL_PROCUREMENT_LOGS,
  INITIAL_SOCIETY_REQUESTS,
  DEFAULT_STORE
} from './data';

// Re-export all static schemas and initial seed data for 100% backward compatibility
export {
  INITIAL_WAREHOUSES,
  INITIAL_SHOPS,
  INITIAL_EMPLOYEES,
  INITIAL_SOCIETIES,
  INITIAL_CATEGORIES,
  INITIAL_UNITS,
  INITIAL_PRODUCTS,
  INITIAL_ORDERS,
  INITIAL_WITHDRAWALS,
  INITIAL_PROCUREMENT_LOGS,
  INITIAL_SOCIETY_REQUESTS,
  DEFAULT_STORE
};

// Helper to initialize and retrieve reactive store from localStorage
const STORAGE_KEY = 'freshioz_master_store_v1';

export function getFreshiozStore() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      const initial = { ...DEFAULT_STORE };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(initial));
      return initial;
    }

    const parsed = JSON.parse(raw);
    let hasUpdates = false;

    // Ensure categories master exists
    if (!parsed.categories || parsed.categories.length === 0) {
      parsed.categories = INITIAL_CATEGORIES;
      hasUpdates = true;
    }

    // Ensure packaging units master exists
    if (!parsed.units || parsed.units.length === 0) {
      parsed.units = INITIAL_UNITS;
      hasUpdates = true;
    }

    // Ensure employees master exists & has store employees
    if (!parsed.employees || parsed.employees.length < INITIAL_EMPLOYEES.length) {
      const existingEmpIds = new Set((parsed.employees || []).map(e => e.id));
      const missingEmps = INITIAL_EMPLOYEES.filter(e => !existingEmpIds.has(e.id));
      parsed.employees = [...(parsed.employees || []), ...missingEmps];
      hasUpdates = true;
    }

    // Ensure multiple warehouses exist
    if (!parsed.warehouses || parsed.warehouses.length < INITIAL_WAREHOUSES.length) {
      const existingWhIds = new Set((parsed.warehouses || []).map(w => w.id));
      const missingWh = INITIAL_WAREHOUSES.filter(w => !existingWhIds.has(w.id));
      parsed.warehouses = [...(parsed.warehouses || []), ...missingWh];
      hasUpdates = true;
    }

    // Ensure shops exist & have staff members
    if (!parsed.shops || parsed.shops.length < INITIAL_SHOPS.length) {
      const existingShopIds = new Set((parsed.shops || []).map(s => s.id));
      const missingShops = INITIAL_SHOPS.filter(s => !existingShopIds.has(s.id));
      parsed.shops = [...(parsed.shops || []), ...missingShops];
      hasUpdates = true;
    }

    // Ensure all shops have staff members populated
    if (parsed.shops) {
      parsed.shops = parsed.shops.map(shop => {
        if (!shop.staff || shop.staff.length === 0) {
          const initShop = INITIAL_SHOPS.find(s => s.id === shop.id);
          hasUpdates = true;
          return {
            ...shop,
            staff: initShop?.staff || [
              { id: `st-${Date.now()}-1`, name: shop.manager || 'Store Manager', role: 'Store Manager', phone: shop.phone || '+91 98450 11999', shift: 'Morning 5:00 AM - 2:00 PM' },
              { id: `st-${Date.now()}-2`, name: 'Delivery Executive', role: 'Delivery Executive', phone: '+91 98450 44200', shift: 'Dawn Dispatch 6:00 AM - 9:30 AM' }
            ]
          };
        }
        return shop;
      });
    }

    // Clean obsolete coldStorageTemp from warehouses
    if (parsed.warehouses) {
      parsed.warehouses = parsed.warehouses.map(w => {
        if ('coldStorageTemp' in w) {
          const { coldStorageTemp, ...rest } = w;
          hasUpdates = true;
          return rest;
        }
        return w;
      });
    }

    // Ensure initial orders exist
    if (parsed && Array.isArray(parsed.orders)) {
      const existingIds = new Set(parsed.orders.map(o => o.id));
      const missingOrders = INITIAL_ORDERS.filter(o => !existingIds.has(o.id));
      if (missingOrders.length > 0) {
        parsed.orders = [...missingOrders, ...parsed.orders];
        hasUpdates = true;
      }
    }

    // Ensure categories and units exist
    if (!parsed.categories || parsed.categories.length === 0) {
      parsed.categories = INITIAL_CATEGORIES;
      hasUpdates = true;
    }
    if (!parsed.units || parsed.units.length === 0 || !parsed.units.some(u => u.name === 'tones')) {
      parsed.units = INITIAL_UNITS;
      hasUpdates = true;
    }

    if (hasUpdates) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(parsed));
    }

    return parsed;
  } catch (e) {
    console.error('Error parsing store from localStorage', e);
    return { ...DEFAULT_STORE };
  }
}

export function saveFreshiozStore(updater) {
  const current = getFreshiozStore();
  const next = typeof updater === 'function' ? updater(current) : { ...current, ...updater };
  localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  // Broadcast across tabs and components
  window.dispatchEvent(new CustomEvent('freshioz_store_updated', { detail: next }));
  return next;
}

export function resetFreshiozStore() {
  localStorage.removeItem(STORAGE_KEY);
  const resetData = { ...DEFAULT_STORE };
  localStorage.setItem(STORAGE_KEY, JSON.stringify(resetData));
  window.dispatchEvent(new CustomEvent('freshioz_store_updated', { detail: resetData }));
  return resetData;
}
