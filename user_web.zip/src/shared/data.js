/**
 * ============================================================================
 * Freshioz Enterprise Master Data Store (Static Schema & Seed Fixtures)
 * ============================================================================
 * This file serves as the Single Source of Truth for all database models,
 * entities, initial seed records, and API contracts for backend implementation.
 *
 * Backends (Node.js/Express, NestJS, FastAPI, Go, Django, Prisma, PostgreSQL):
 * - Table / Collection models map 1:1 with the exported entity structures below.
 * - Seed scripts can ingest these exports directly.
 */

// ============================================================================
// 1. WAREHOUSES (Primary Regional Sorting & Crating Agri-Logistics Hubs)
// ============================================================================
export const INITIAL_WAREHOUSES = [
  {
    id: 'wh-1',
    code: 'WH-BLR-NORTH',
    name: 'Central Agri-Hub North (Sorting & Crating Hub)',
    location: 'Yelahanka Mega Agri Complex, Bengaluru',
    lat: 13.1007,
    lng: 77.5963,
    openTime: '05:00', // 5:00 AM
    cutoffTime: '21:00', // 9:00 PM cutoff for next-day delivery
    capacityTons: 45,
    managerName: 'Rajesh Nayak',
    managerPhone: '+91 98450 22334',
    status: 'ACTIVE',
    slots: [
      { id: 'slot-morning', label: 'Morning Fresh Slot', timeWindow: '06:30 AM - 08:30 AM', desc: 'Direct to Society Drop Desk / Doorstep' },
      { id: 'slot-evening', label: 'Evening Fresh Slot', timeWindow: '05:00 PM - 07:30 PM', desc: 'Evening Return from Work Drop' }
    ]
  },
  {
    id: 'wh-2',
    code: 'WH-BLR-SOUTH',
    name: 'South Bengaluru Agro-Logistics Center',
    location: 'Electronics City Phase 2, Hosur Road Corridor, Bengaluru',
    lat: 12.8399,
    lng: 77.6770,
    openTime: '04:30',
    cutoffTime: '21:30',
    capacityTons: 35,
    managerName: 'Karthik Subbaiah',
    managerPhone: '+91 98450 33441',
    status: 'ACTIVE',
    slots: [
      { id: 'slot-morning', label: 'Morning Fresh Slot', timeWindow: '06:30 AM - 08:30 AM', desc: 'Direct to Society Drop Desk / Doorstep' }
    ]
  }
];

// ============================================================================
// 2. SHOPS / STORES (Local Community Hubs & Fulfillment Outlets)
// ============================================================================
export const INITIAL_SHOPS = [
  {
    id: 'shop-1',
    warehouseId: 'wh-1',
    name: 'Indiranagar Fresh Hub (Shop 1)',
    address: '100ft Road, Defence Colony, Indiranagar, Bengaluru',
    lat: 12.9784,
    lng: 77.6408,
    phone: '+91 98450 11201',
    manager: 'Arun Kumar',
    staff: [
      { id: 'st-101', name: 'Arun Kumar', role: 'Store Manager', phone: '+91 98450 11201', shift: 'Morning 5:00 AM - 2:00 PM' },
      { id: 'st-102', name: 'Raju M', role: 'Delivery Executive (Route A)', phone: '+91 98450 44201', shift: 'Dawn Dispatch 6:00 AM - 9:30 AM' },
      { id: 'st-103', name: 'Sandeep K', role: 'Delivery Executive (Route B)', phone: '+91 98450 44202', shift: 'Dawn Dispatch 6:00 AM - 9:30 AM' },
      { id: 'st-104', name: 'Manjunath B', role: 'Sorting & Crating Assistant', phone: '+91 98450 44203', shift: 'Morning 5:00 AM - 1:00 PM' }
    ],
    status: 'ACTIVE'
  },
  {
    id: 'shop-2',
    warehouseId: 'wh-1',
    name: 'Whitefield Agro Express (Shop 2)',
    address: 'ITPL Main Road, Prestige Shantiniketan Junction, Bengaluru',
    lat: 12.9856,
    lng: 77.7321,
    phone: '+91 98450 11202',
    manager: 'Deepa Hegde',
    staff: [
      { id: 'st-201', name: 'Deepa Hegde', role: 'Store Manager', phone: '+91 98450 11202', shift: 'Morning 5:00 AM - 2:00 PM' },
      { id: 'st-202', name: 'Venkatesh R', role: 'Delivery Executive (Route A)', phone: '+91 98450 44301', shift: 'Dawn Dispatch 6:00 AM - 9:30 AM' },
      { id: 'st-203', name: 'Prasad N', role: 'Sorting & Crating Assistant', phone: '+91 98450 44302', shift: 'Morning 5:00 AM - 1:00 PM' }
    ],
    status: 'ACTIVE'
  },
  {
    id: 'shop-3',
    warehouseId: 'wh-1',
    name: 'Koramangala Fresh Point (Shop 3)',
    address: '80ft Road, 4th Block, Koramangala, Bengaluru',
    lat: 12.9352,
    lng: 77.6245,
    phone: '+91 98450 11203',
    manager: 'Kiran Gowda',
    staff: [
      { id: 'st-301', name: 'Kiran Gowda', role: 'Store Manager', phone: '+91 98450 11203', shift: 'Morning 5:00 AM - 2:00 PM' },
      { id: 'st-302', name: 'Santosh Kumar', role: 'Delivery Executive', phone: '+91 98450 44401', shift: 'Dawn Dispatch 6:00 AM - 9:30 AM' }
    ],
    status: 'ACTIVE'
  },
  {
    id: 'shop-4',
    warehouseId: 'wh-2',
    name: 'HSR Sector 2 Hub Point (Shop 4)',
    address: '27th Main Road, Sector 2, HSR Layout, Bengaluru',
    lat: 12.9110,
    lng: 77.6388,
    phone: '+91 98450 11204',
    manager: 'Suresh Patil',
    staff: [
      { id: 'st-401', name: 'Suresh Patil', role: 'Store Manager', phone: '+91 98450 11204', shift: 'Morning 5:00 AM - 2:00 PM' },
      { id: 'st-402', name: 'Anil Kumar', role: 'Delivery Executive', phone: '+91 98450 44501', shift: 'Dawn Dispatch 6:00 AM - 9:30 AM' }
    ],
    status: 'ACTIVE'
  },
  {
    id: 'shop-5',
    warehouseId: 'wh-2',
    name: 'Electronic City Phase 1 Express (Shop 5)',
    address: 'Velankani Drive, Electronic City Phase 1, Bengaluru',
    lat: 12.8452,
    lng: 77.6602,
    phone: '+91 98450 11205',
    manager: 'Manoj Hegde',
    staff: [
      { id: 'st-501', name: 'Manoj Hegde', role: 'Store Manager', phone: '+91 98450 11205', shift: 'Morning 5:00 AM - 2:00 PM' },
      { id: 'st-502', name: 'Raghavendra K', role: 'Delivery Executive', phone: '+91 98450 44601', shift: 'Dawn Dispatch 6:00 AM - 9:30 AM' }
    ],
    status: 'ACTIVE'
  }
];

// ============================================================================
// 3. EMPLOYEES & WORKFORCE (Multi-Role Personnel & Super Admins)
// ============================================================================
export const INITIAL_EMPLOYEES = [
  {
    id: 'emp-101',
    name: 'Vikramaditya Rao',
    phone: '9845011000',
    email: 'vikram.rao@freshioz.com',
    roles: ['SUPER_ADMIN'], // Super Admin has platform-wide authority
    assignedWarehouseId: 'ALL',
    assignedLocationName: 'All Hubs & Warehouses (Citywide)',
    status: 'ACTIVE',
    dateJoined: '2026-01-10',
    notes: 'Platform Director & Operations Head'
  },
  {
    id: 'emp-102',
    name: 'Rajesh Nayak',
    phone: '9845022334',
    email: 'rajesh.ops@freshioz.com',
    roles: ['WAREHOUSE_MANAGER', 'PROCUREMENT_OFFICER'],
    assignedWarehouseId: 'wh-1',
    assignedLocationName: 'Central Agri-Hub North (WH-1)',
    status: 'ACTIVE',
    dateJoined: '2026-02-01',
    notes: 'Manages dawn sorting lines and Kolar APMC procurement'
  },
  {
    id: 'emp-103',
    name: 'Sneha Sharma',
    phone: '9845033445',
    email: 'sneha.sales@freshioz.com',
    roles: ['SALES_OFFICER'],
    assignedWarehouseId: 'wh-1',
    assignedLocationName: 'Indiranagar & Whitefield Corridor',
    status: 'ACTIVE',
    dateJoined: '2026-03-05',
    notes: 'Apartment association partner agreements & hostel mess tie-ups'
  },
  {
    id: 'emp-104',
    name: 'Mohan Gowda',
    phone: '9845044556',
    email: 'mohan.mandi@freshioz.com',
    roles: ['PROCUREMENT_OFFICER'],
    assignedWarehouseId: 'wh-1',
    assignedLocationName: 'Kolar & Chikkaballapur APMC Yards',
    status: 'ACTIVE',
    dateJoined: '2026-02-15',
    notes: 'Mandi pricing negotiator and quality grading lead'
  },
  {
    id: 'emp-105',
    name: 'Karthik Subbaiah',
    phone: '9845033441',
    email: 'karthik.s@freshioz.com',
    roles: ['WAREHOUSE_MANAGER', 'SALES_OFFICER'],
    assignedWarehouseId: 'wh-2',
    assignedLocationType: 'WAREHOUSE',
    assignedLocationName: 'South Bengaluru Agro-Logistics Center (WH-2)',
    status: 'ACTIVE',
    dateJoined: '2026-02-25',
    notes: 'Electronics City logistics hub and tech park hostel accounts'
  },
  // Store Level Employees
  {
    id: 'emp-201',
    name: 'Arun Kumar',
    phone: '9845011201',
    email: 'arun.indiranagar@freshioz.com',
    roles: ['STORE_MANAGER'],
    assignedWarehouseId: 'shop-1',
    assignedLocationType: 'STORE',
    assignedLocationName: 'Indiranagar Fresh Hub (Shop 1)',
    status: 'ACTIVE',
    dateJoined: '2026-02-10',
    notes: 'Store in-charge, local customer support and morning dispatch'
  },
  {
    id: 'emp-202',
    name: 'Raju M',
    phone: '9845044201',
    email: 'raju.delivery@freshioz.com',
    roles: ['DELIVERY_EXECUTIVE'],
    assignedWarehouseId: 'shop-1',
    assignedLocationType: 'STORE',
    assignedLocationName: 'Indiranagar Fresh Hub (Shop 1)',
    status: 'ACTIVE',
    dateJoined: '2026-03-01',
    notes: 'Morning Route A delivery executive for HAL 2nd Stage & Defence Colony'
  },
  {
    id: 'emp-203',
    name: 'Deepa Hegde',
    phone: '9845011202',
    email: 'deepa.whitefield@freshioz.com',
    roles: ['STORE_MANAGER'],
    assignedWarehouseId: 'shop-2',
    assignedLocationType: 'STORE',
    assignedLocationName: 'Whitefield Agro Express (Shop 2)',
    status: 'ACTIVE',
    dateJoined: '2026-02-12',
    notes: 'Store in-charge for Prestige Shantiniketan corridor'
  },
  {
    id: 'emp-204',
    name: 'Venkatesh R',
    phone: '9845044301',
    email: 'venkatesh.wfd@freshioz.com',
    roles: ['DELIVERY_EXECUTIVE'],
    assignedWarehouseId: 'shop-2',
    assignedLocationType: 'STORE',
    assignedLocationName: 'Whitefield Agro Express (Shop 2)',
    status: 'ACTIVE',
    dateJoined: '2026-03-04',
    notes: 'Morning Route A delivery executive for Whitefield societies'
  },
  {
    id: 'emp-205',
    name: 'Kiran Gowda',
    phone: '9845011203',
    email: 'kiran.kora@freshioz.com',
    roles: ['STORE_MANAGER'],
    assignedWarehouseId: 'shop-3',
    assignedLocationType: 'STORE',
    assignedLocationName: 'Koramangala Fresh Point (Shop 3)',
    status: 'ACTIVE',
    dateJoined: '2026-02-15',
    notes: 'Store in-charge for Koramangala 4th & 5th blocks'
  },
  {
    id: 'emp-206',
    name: 'Suresh Patil',
    phone: '9845011204',
    email: 'suresh.hsr@freshioz.com',
    roles: ['STORE_MANAGER'],
    assignedWarehouseId: 'shop-4',
    assignedLocationType: 'STORE',
    assignedLocationName: 'HSR Sector 2 Hub Point (Shop 4)',
    status: 'ACTIVE',
    dateJoined: '2026-02-18',
    notes: 'Store in-charge for HSR Layout residential clusters'
  },
  {
    id: 'emp-207',
    name: 'Manoj Hegde',
    phone: '9845011205',
    email: 'manoj.ecity@freshioz.com',
    roles: ['STORE_MANAGER'],
    assignedWarehouseId: 'shop-5',
    assignedLocationType: 'STORE',
    assignedLocationName: 'Electronic City Express (Shop 5)',
    status: 'ACTIVE',
    dateJoined: '2026-02-20',
    notes: 'Store in-charge for Electronic City Phase 1 gated communities'
  }
];

// ============================================================================
// 4. SOCIETIES & HOSTELS (Community Delivery Destinations & Cashbacks)
// ============================================================================
export const INITIAL_SOCIETIES = [
  {
    id: 'soc-1',
    name: 'Greenfield Heights Apartments',
    type: 'APARTMENT',
    address: '12th Cross, HAL 2nd Stage, Indiranagar, Bengaluru',
    lat: 12.9725,
    lng: 77.6480,
    nearestShopId: 'shop-1',
    secretaryName: 'Raghavan Sundaram (President)',
    secretaryPhone: '9876543210',
    totalFloors: 14,
    totalUnits: 280,
    unitPlaceholder: 'e.g., Tower B - Flat 402',
    deliveryMode: 'SOCIETY_DESK',
    status: 'APPROVED',
    commissionType: 'PERCENTAGE',
    commissionValue: 3.5,
    balanceEarned: 14250,
    totalOrdersDelivered: 412,
    bankDetails: {
      bankName: 'HDFC Bank',
      accountHolder: 'Greenfield Heights Apartment Owners Welfare Association',
      accountNumber: '50100492817291',
      ifscCode: 'HDFC0001742',
      branch: 'Indiranagar Branch'
    }
  },
  {
    id: 'soc-2',
    name: 'Prestige Lavender Park Towers',
    type: 'APARTMENT',
    address: 'ECC Road, Whitefield, Bengaluru',
    lat: 12.9801,
    lng: 77.7410,
    nearestShopId: 'shop-2',
    secretaryName: 'Meenakshi Iyer (Secretary)',
    secretaryPhone: '9845012345',
    totalFloors: 18,
    totalUnits: 360,
    unitPlaceholder: 'e.g., Wing C - Flat 804',
    deliveryMode: 'DOORSTEP',
    status: 'APPROVED',
    commissionType: 'FLAT',
    commissionValue: 6,
    balanceEarned: 8940,
    totalOrdersDelivered: 245,
    bankDetails: {
      bankName: 'State Bank of India',
      accountHolder: 'Prestige Lavender Residents Welfare Association',
      accountNumber: '39281928371',
      ifscCode: 'SBIN0040211',
      branch: 'Whitefield Branch'
    }
  },
  {
    id: 'soc-3',
    name: 'Stanza Living - Lavender House (Girls Hostel)',
    type: 'HOSTEL',
    address: '5th Main, 7th Sector, HSR Layout / Koramangala Border',
    lat: 12.9240,
    lng: 77.6320,
    nearestShopId: 'shop-3',
    secretaryName: 'Nandini Roy (Warden & Operations)',
    secretaryPhone: '9811223344',
    totalFloors: 5,
    totalUnits: 120,
    unitPlaceholder: 'e.g., Room 302 / Dining Mess',
    deliveryMode: 'SOCIETY_DESK',
    status: 'APPROVED',
    commissionType: 'PERCENTAGE',
    commissionValue: 4.0,
    balanceEarned: 19800,
    totalOrdersDelivered: 184,
    bankDetails: {
      bankName: 'ICICI Bank',
      accountHolder: 'Stanza Living Hostel Operations',
      accountNumber: '000205015621',
      ifscCode: 'ICIC0000104',
      branch: 'Koramangala Branch'
    }
  },
  {
    id: 'soc-4',
    name: 'Sobha Silicon Oasis',
    type: 'APARTMENT',
    address: 'Hosa Road, Off Hosur Road, Electronic City, Bengaluru',
    lat: 12.8682,
    lng: 77.6540,
    nearestShopId: 'shop-4',
    secretaryName: 'Anil Deshmukh (Secretary)',
    secretaryPhone: '9845088991',
    totalFloors: 16,
    totalUnits: 420,
    unitPlaceholder: 'e.g., Block 3 - Flat 1102',
    deliveryMode: 'SOCIETY_DESK',
    status: 'PENDING',
    commissionType: 'PERCENTAGE',
    commissionValue: 3.5,
    balanceEarned: 0,
    totalOrdersDelivered: 0,
    bankDetails: {
      bankName: 'Axis Bank',
      accountHolder: 'Sobha Silicon Oasis Apartment Association',
      accountNumber: '918020048192019',
      ifscCode: 'UTIB0000682',
      branch: 'Electronic City'
    }
  }
];

// ============================================================================
// 5. PRODUCE CATEGORIES
// ============================================================================
export const INITIAL_CATEGORIES = [
  { id: 'VEGETABLES', name: 'Fresh Vegetables', slug: 'vegetables', icon: '🥦', description: 'Daily farm-fresh kitchen essentials and root vegetables', status: 'ACTIVE' },
  { id: 'FRUITS', name: 'Seasonal Fruits', slug: 'fruits', icon: '🍎', description: 'Sweet, tree-ripened orchard and citrus fruits', status: 'ACTIVE' },
  { id: 'LEAFY_GREENS', name: 'Leafy Greens & Herbs', slug: 'leafy-greens', icon: '🌿', description: 'Hydro-washed palak, methi, coriander, and fresh culinary herbs', status: 'ACTIVE' },
  { id: 'ORGANIC', name: 'Certified Organic', slug: 'organic', icon: '🌱', description: 'Zero pesticide certified organic vegetables and grains', status: 'ACTIVE' },
  { id: 'EXOTIC', name: 'Exotic & Salads', slug: 'exotic', icon: '🥑', description: 'Avocados, bell peppers, broccoli, lettuce, and salad kits', status: 'ACTIVE' }
];

// ============================================================================
// 6. PACKAGING UNITS (Simplified Master Units)
// ============================================================================
export const INITIAL_UNITS = [
  { id: 'u-kg', name: 'kg', label: 'Kilogram (kg)', description: 'Standard consumer produce weight', status: 'ACTIVE' },
  { id: 'u-tones', name: 'tones', label: 'Metric Ton (tones)', description: 'Mandi truckloads and warehouse handling', status: 'ACTIVE' },
  { id: 'u-crate', name: 'crate', label: 'Standard Crate (crate)', description: 'Standard 20kg APMC harvesting / shipping crate', status: 'ACTIVE' },
  { id: 'u-g', name: 'g', label: 'Grams (g)', description: 'Punnet packs & small quantities (e.g., 250g, 500g)', status: 'ACTIVE' },
  { id: 'u-pack', name: 'pack', label: 'Prepack Polybag (pack)', description: 'Pre-sorted combo vegetables & tray packs', status: 'ACTIVE' },
  { id: 'u-bunch', name: 'bunch', label: 'Harvest Bunch (bunch)', description: 'Fresh leafy greens and herbs tied bunch', status: 'ACTIVE' }
];

// ============================================================================
// 7. PRODUCE CATALOG & PRODUCTS
// Note: Pricing is dynamically governed via /daily-pricing table.
// ============================================================================
export const INITIAL_PRODUCTS = [
  {
    id: 'prod-1',
    name: 'Farm Fresh Hybrid Tomatoes (Grade A)',
    category: 'VEGETABLES',
    image: 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?w=600&auto=format&fit=crop&q=80',
    badge: 'Farm Fresh',
    tags: ['Firm Red', 'Salad Grade', 'Mandi Direct'],
    origin: 'Kolar Agro Mandi, Karnataka',
    shelfLife: '4-5 Days at room temperature',
    desc: 'Firm, naturally vine-ripened hybrid tomatoes. Thick pulp, optimal acidity for Indian gravies and curries.',
    retailUnit: '1 kg',
    retailPrice: 34,
    retailMarketPrice: 48,
    gstPercent: 0,
    wholesaleUnit: '1 Crate (20 kg)',
    wholesalePrice: 480, // Rs. 24/kg
    wholesaleMinQty: 1,
    wholesaleSavings: 'Save 29%',
    dailyProcuredQty: 620
  },
  {
    id: 'prod-2',
    name: 'Organic Red Onions (Medium Size)',
    category: 'VEGETABLES',
    image: 'https://images.unsplash.com/photo-1618512496248-a07fe83aa8cb?w=600&auto=format&fit=crop&q=80',
    badge: 'Direct Mandi',
    tags: ['Pungent', 'Thin Skin', 'Long Storage'],
    origin: 'Lasalgaon / Hubballi Mandi',
    shelfLife: '2-3 Weeks dry cool storage',
    desc: 'Crisp, pungent red onions with tight skins. High dry-matter content for rich caramelized gravies.',
    retailUnit: '1 kg',
    retailPrice: 42,
    retailMarketPrice: 58,
    gstPercent: 0,
    wholesaleUnit: '1 Mesh Sack (25 kg)',
    wholesalePrice: 775, // Rs. 31/kg
    wholesaleMinQty: 1,
    wholesaleSavings: 'Save 26%',
    dailyProcuredQty: 850
  },
  {
    id: 'prod-3',
    name: 'Baby Potato (Dum Aloo Special)',
    category: 'VEGETABLES',
    image: 'https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=600&auto=format&fit=crop&q=80',
    badge: 'Clean Soil',
    tags: ['Washed', 'Firm Texture'],
    origin: 'Hassan Farm Belt',
    shelfLife: '2-3 Weeks in dark airy basket',
    desc: 'Tender baby potatoes, spotless skins, washed and sorted. Perfect for roasting, gravies, and dum aloo.',
    retailUnit: '1 kg',
    retailPrice: 32,
    retailMarketPrice: 45,
    gstPercent: 0,
    wholesaleUnit: '1 Jute Sack (25 kg)',
    wholesalePrice: 650, // Rs. 26/kg
    wholesaleMinQty: 1,
    wholesaleSavings: 'Save 28%',
    dailyProcuredQty: 580
  },
  {
    id: 'prod-4',
    name: 'Crisp Green Capsicum (Shimla Mirch)',
    category: 'VEGETABLES',
    image: 'https://images.unsplash.com/photo-1563565375-f3fdfdbefa83?w=600&auto=format&fit=crop&q=80',
    badge: 'Polyhouse Fresh',
    tags: ['Crunchy', 'Salad Grade'],
    origin: 'Chikkaballapur Polyhouse Hub',
    shelfLife: '5-7 Days refrigerated',
    desc: 'Vibrant emerald green, thick-walled bell peppers with juicy sweet crunch. Zero bitterness.',
    retailUnit: '500 g',
    retailPrice: 38,
    retailMarketPrice: 52,
    gstPercent: 0,
    wholesaleUnit: '1 Master Carton (10 kg)',
    wholesalePrice: 540,
    wholesaleMinQty: 1,
    wholesaleSavings: 'Save 29%',
    dailyProcuredQty: 180
  },
  {
    id: 'prod-5',
    name: 'Fresh Palak (Spinach) - Root Cleaned',
    category: 'LEAFY_GREENS',
    image: 'https://images.unsplash.com/photo-1576045057995-568f588f82fb?w=600&auto=format&fit=crop&q=80',
    badge: 'Dawn Picked',
    tags: ['Hydro-Washed', 'Tender Leaves'],
    origin: 'Anekal Organic Farms',
    shelfLife: '2 Days (Use fresh for maximum iron)',
    desc: 'Tender baby spinach leaves, gently cleaned of mud. Full of natural vitamins, iron, and deep green freshness.',
    retailUnit: '250 g Bunch',
    retailPrice: 18,
    retailMarketPrice: 28,
    gstPercent: 0,
    wholesaleUnit: '1 Crate (20 Bunches)',
    wholesalePrice: 260,
    wholesaleMinQty: 1,
    wholesaleSavings: 'Save 28%',
    dailyProcuredQty: 220
  },
  {
    id: 'prod-6',
    name: 'Fragrant Coriander & Mint Combo',
    category: 'LEAFY_GREENS',
    image: 'https://images.unsplash.com/photo-1598170845058-32b9d6a5da37?w=600&auto=format&fit=crop&q=80',
    badge: 'Aromatic',
    tags: ['Farm Fresh Pair', 'Pudina + Kothmir'],
    origin: 'Devanahalli Greens Cluster',
    shelfLife: '4-5 Days in damp towel wrap',
    desc: 'Freshly harvested mountain coriander with strong aromatic roots alongside fragrant spearmint leaves.',
    retailUnit: '1 Combo Pack',
    retailPrice: 24,
    retailMarketPrice: 35,
    gstPercent: 0,
    wholesaleUnit: '1 Bundle (10 Combos)',
    wholesalePrice: 160,
    wholesaleMinQty: 1,
    wholesaleSavings: 'Save 33%',
    dailyProcuredQty: 190
  },
  {
    id: 'prod-7',
    name: 'Royal Shimla Red Delicious Apples',
    category: 'FRUITS',
    image: 'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?w=600&auto=format&fit=crop&q=80',
    badge: 'Orchard Fresh',
    tags: ['Natural Wax Free', 'Crisp & Sweet'],
    origin: 'Kotgarh Valley, Himachal Pradesh',
    shelfLife: '10-14 Days cool storage',
    desc: 'Sweet, juicy, natural red blush apples from high-altitude Himachal orchards. Bursting with fresh crunch.',
    retailUnit: '4 pcs (Approx 600g)',
    retailPrice: 125,
    retailMarketPrice: 160,
    gstPercent: 0,
    wholesaleUnit: '1 Master Carton (10 kg)',
    wholesalePrice: 1650,
    wholesaleMinQty: 1,
    wholesaleSavings: 'Save 21%',
    dailyProcuredQty: 120
  },
  {
    id: 'prod-8',
    name: 'Juicy Nagpur Sweet Oranges (Mosambi)',
    category: 'FRUITS',
    image: 'https://images.unsplash.com/photo-1547514701-42782101795e?w=600&auto=format&fit=crop&q=80',
    badge: 'Immunity Boost',
    tags: ['Rich in Vitamin C', 'Juicing Grade'],
    origin: 'Nagpur Citrus Groves',
    shelfLife: '7-10 Days',
    desc: 'Sun-ripened sweet citrus with high juice yield. Sweet taste with refreshing citrus undertone.',
    retailUnit: '1 kg',
    retailPrice: 78,
    retailMarketPrice: 105,
    gstPercent: 0,
    wholesaleUnit: '1 Crate (15 kg)',
    wholesalePrice: 890,
    wholesaleMinQty: 1,
    wholesaleSavings: 'Save 24%',
    dailyProcuredQty: 160
  },
  {
    id: 'prod-9',
    name: 'Robusta Golden Bananas (Yellaki)',
    category: 'FRUITS',
    image: 'https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?w=600&auto=format&fit=crop&q=80',
    badge: 'Naturally Ripened',
    tags: ['Ethylene Free', 'Kid Favourite'],
    origin: 'Mysuru Farm Belt',
    shelfLife: '3-4 Days',
    desc: 'Naturally ripened Karnataka Yellaki bananas. Sweet creamy texture, no chemical ripening agents.',
    retailUnit: '500 g',
    retailPrice: 42,
    retailMarketPrice: 58,
    gstPercent: 0,
    wholesaleUnit: '1 Crate (12 kg)',
    wholesalePrice: 720,
    wholesaleMinQty: 1,
    wholesaleSavings: 'Save 28%',
    dailyProcuredQty: 240
  },
  {
    id: 'prod-10',
    name: 'Exotic Green Broccoli Florets',
    category: 'EXOTIC',
    image: 'https://images.unsplash.com/photo-1459411621453-7b03977f4bfc?w=600&auto=format&fit=crop&q=80',
    badge: 'Superfood',
    tags: ['Polyhouse', 'Antioxidant Rich'],
    origin: 'Ooty Nilgiri Hills',
    shelfLife: '4-6 Days refrigerated',
    desc: 'Dense, dark green florets loaded with antioxidants. Excellent for stir-fries, roasting & salads.',
    retailUnit: '1 pc (Approx 350-400g)',
    retailPrice: 65,
    retailMarketPrice: 90,
    gstPercent: 0,
    wholesaleUnit: '1 Box (10 pcs)',
    wholesalePrice: 480,
    wholesaleMinQty: 1,
    wholesaleSavings: 'Save 26%',
    dailyProcuredQty: 90
  },
  {
    id: 'prod-11',
    name: 'Button Mushrooms Pack (Grade A)',
    category: 'EXOTIC',
    image: 'https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?w=600&auto=format&fit=crop&q=80',
    badge: 'Freshly Picked',
    tags: ['Moisture Controlled', 'High Protein'],
    origin: 'Nilgiri Mushroom Farms',
    shelfLife: '3 Days in chilled pack',
    desc: 'Plump, spotless white button mushrooms grown in temperature-regulated sterile farms.',
    retailUnit: '200 g Punnet',
    retailPrice: 48,
    retailMarketPrice: 65,
    gstPercent: 0,
    wholesaleUnit: '1 Master Crate (15 Punnets)',
    wholesalePrice: 540,
    wholesaleMinQty: 1,
    wholesaleSavings: 'Save 25%',
    dailyProcuredQty: 110
  },
  {
    id: 'prod-12',
    name: 'Tender Coconut (Sweet Water)',
    category: 'FRUITS',
    image: 'https://images.unsplash.com/photo-1525385133512-2f3bdd039054?w=600&auto=format&fit=crop&q=80',
    badge: 'Electrolyte Rich',
    tags: ['350ml+ Water', 'Maddur Tender'],
    origin: 'Maddur Coconut Mandi',
    shelfLife: '7 Days',
    desc: 'Large green tender coconuts with sweet refreshing water and soft malai.',
    retailUnit: '1 pc',
    retailPrice: 52,
    retailMarketPrice: 65,
    gstPercent: 0,
    wholesaleUnit: '1 Net Bag (20 pcs)',
    wholesalePrice: 780,
    wholesaleMinQty: 1,
    wholesaleSavings: 'Save 25%',
    dailyProcuredQty: 300
  }
];

// ============================================================================
// 8. ORDERS (Batched Next-Day Delivery Customer Orders)
// ============================================================================
export const INITIAL_ORDERS = [
  {
    id: 'FZ-2026-8815',
    userId: 'user-1',
    userName: 'Kavitha R',
    userPhone: '9845012345',
    societyId: 'soc-1',
    societyName: 'Greenfield Heights Apartments',
    flatNo: 'Tower B - Flat 402',
    orderType: 'RETAIL',
    items: [
      { id: 'prod-7', name: 'Royal Shimla Red Delicious Apples', unit: '4 pcs (Approx 600g)', qty: 2, price: 125 },
      { id: 'prod-8', name: 'Juicy Nagpur Sweet Oranges (Mosambi)', unit: '1 kg', qty: 1, price: 78 },
      { id: 'prod-12', name: 'Tender Coconut (Sweet Water)', unit: '1 pc', qty: 2, price: 52 }
    ],
    subtotal: 432,
    deliveryFee: 0,
    gstAmount: 0,
    totalAmount: 432,
    deliveryDate: '2026-10-12',
    deliverySlot: 'Morning Fresh Slot (06:30 AM - 08:30 AM)',
    orderPlacedAt: '2026-10-11T19:10:00',
    status: 'AT_WAREHOUSE', // Sorting & Packing at Hub
    paymentMethod: 'UPI',
    societyCommissionEarned: 15.12
  },
  {
    id: 'FZ-2026-8812',
    userId: 'user-1',
    userName: 'Kavitha R',
    userPhone: '9845012345',
    societyId: 'soc-1',
    societyName: 'Greenfield Heights Apartments',
    flatNo: 'Tower B - Flat 402',
    orderType: 'RETAIL',
    items: [
      { id: 'prod-1', name: 'Farm Fresh Hybrid Tomatoes', unit: '1 kg', qty: 2, price: 34 },
      { id: 'prod-2', name: 'Organic Red Onions (Medium)', unit: '1 kg', qty: 1, price: 42 },
      { id: 'prod-5', name: 'Fresh Palak (Spinach)', unit: '250 g Bunch', qty: 2, price: 18 }
    ],
    subtotal: 146,
    deliveryFee: 25,
    gstAmount: 0,
    totalAmount: 171,
    deliveryDate: '2026-10-12',
    deliverySlot: 'Morning Fresh Slot (06:30 AM - 08:30 AM)',
    orderPlacedAt: '2026-10-11T18:42:00',
    status: 'CONFIRMED',
    paymentMethod: 'UPI',
    societyCommissionEarned: 5.11
  },
  {
    id: 'FZ-2026-8809',
    userId: 'user-2',
    userName: 'Hostel Mess - Stanza Living',
    userPhone: '9811223344',
    societyId: 'soc-3',
    societyName: 'Stanza Living - Lavender House',
    flatNo: 'Hostel Kitchen / Dining Hall',
    orderType: 'WHOLESALE',
    items: [
      { id: 'prod-1', name: 'Wholesale Tomato Crate (20 kg)', unit: '1 Crate (20 kg)', qty: 2, price: 480 },
      { id: 'prod-2', name: 'Wholesale Onion Mesh Sack (25 kg)', unit: '1 Mesh Sack (25 kg)', qty: 1, price: 775 },
      { id: 'prod-3', name: 'Wholesale Potato Jute Sack (25 kg)', unit: '1 Jute Sack (25 kg)', qty: 1, price: 650 }
    ],
    subtotal: 2385,
    deliveryFee: 0,
    gstAmount: 0,
    totalAmount: 2385,
    deliveryDate: '2026-10-12',
    deliverySlot: 'Morning Fresh Slot (06:30 AM - 08:30 AM)',
    orderPlacedAt: '2026-10-11T16:15:00',
    status: 'PROCURING',
    paymentMethod: 'PAY_ON_DELIVERY',
    societyCommissionEarned: 95.40
  },
  {
    id: 'FZ-2026-8740',
    userId: 'user-1',
    userName: 'Kavitha R',
    userPhone: '9845012345',
    societyId: 'soc-1',
    societyName: 'Greenfield Heights Apartments',
    flatNo: 'Tower B - Flat 402',
    orderType: 'RETAIL',
    items: [
      { id: 'prod-3', name: 'Baby Potato (Dum Aloo Special)', unit: '1 kg', qty: 2, price: 32 },
      { id: 'prod-4', name: 'Crisp Green Capsicum (Shimla Mirch)', unit: '500 g', qty: 2, price: 38 },
      { id: 'prod-6', name: 'Fragrant Coriander & Mint Combo', unit: '1 Combo Pack', qty: 1, price: 24 },
      { id: 'prod-10', name: 'Exotic Green Broccoli Florets', unit: '1 pc', qty: 2, price: 65 }
    ],
    subtotal: 270,
    deliveryFee: 0,
    gstAmount: 0,
    totalAmount: 270,
    deliveryDate: '2026-10-10',
    deliverySlot: 'Morning Fresh Slot (06:30 AM - 08:30 AM)',
    orderPlacedAt: '2026-10-09T17:25:00',
    deliveredAt: '2026-10-10T07:15:00',
    status: 'DELIVERED',
    paymentMethod: 'UPI',
    societyCommissionEarned: 9.45
  },
  {
    id: 'FZ-2026-8699',
    userId: 'user-1',
    userName: 'Kavitha R',
    userPhone: '9845012345',
    societyId: 'soc-1',
    societyName: 'Greenfield Heights Apartments',
    flatNo: 'Tower B - Flat 402',
    orderType: 'RETAIL',
    items: [
      { id: 'prod-11', name: 'Button Mushrooms Pack (Grade A)', unit: '200 g Punnet', qty: 3, price: 48 }
    ],
    subtotal: 144,
    deliveryFee: 25,
    gstAmount: 0,
    totalAmount: 169,
    deliveryDate: '2026-10-08',
    deliverySlot: 'Morning Fresh Slot (06:30 AM - 08:30 AM)',
    orderPlacedAt: '2026-10-07T14:10:00',
    status: 'CANCELLED',
    cancelledReason: 'Resident requested date change before dispatch cut-off',
    paymentMethod: 'UPI',
    refundStatus: 'REFUNDED_TO_UPI',
    societyCommissionEarned: 0
  }
];

// ============================================================================
// 9. SOCIETY WITHDRAWALS & PAYOUTS
// ============================================================================
export const INITIAL_WITHDRAWALS = [
  {
    id: 'WDR-9021',
    societyId: 'soc-1',
    societyName: 'Greenfield Heights Apartments',
    amount: 5000,
    bankDetails: 'HDFC Bank - A/C ...7291 (IFSC: HDFC0001742)',
    requestedAt: '2026-10-09T11:20:00',
    status: 'COMPLETED',
    bankUtr: 'HDFCN261009827361',
    disbursedAt: '2026-10-09T15:30:00'
  },
  {
    id: 'WDR-9044',
    societyId: 'soc-3',
    societyName: 'Stanza Living - Lavender House',
    amount: 3500,
    bankDetails: 'ICICI Bank - A/C ...5621 (IFSC: ICIC0000104)',
    requestedAt: '2026-10-11T09:40:00',
    status: 'PENDING_APPROVAL',
    bankUtr: null,
    disbursedAt: null
  }
];

// ============================================================================
// 10. PROCUREMENT LOGS & MANDI BILLS
// ============================================================================
export const INITIAL_PROCUREMENT_LOGS = [
  {
    id: 'PROC-501',
    mandiName: 'Kolar Agro Produce Market (APMC Yard)',
    vendorName: 'M.K. Traders & Farmers Group',
    lat: 13.1362,
    lng: 78.1347,
    items: [
      { name: 'Farm Fresh Tomatoes', qty: '450 kg (22 Crates)', rate: 18.5, total: 8325 },
      { name: 'Capsicum Green', qty: '190 kg', rate: 32, total: 6080 }
    ],
    destinationType: 'WAREHOUSE',
    destinationName: 'Central Agri-Hub North',
    totalAmountPaid: 14405,
    paymentMode: 'IMPS_TRANSFER',
    billNumber: 'APMC/KLR/2026/8942',
    timestamp: '2026-10-11T04:45:00'
  }
];

// ============================================================================
// 11. INBOUND CUSTOMER BUILDING REQUESTS
// ============================================================================
export const INITIAL_SOCIETY_REQUESTS = [
  {
    id: 'req-1',
    requesterName: 'Aditya Sen',
    requesterPhone: '9845077221',
    requesterEmail: 'aditya.sen@gmail.com',
    societyName: 'Godrej Woodsman Estate',
    address: 'Bellary Road, Hebbal, Bengaluru',
    lat: 13.0450,
    lng: 77.5920,
    estimatedFlats: 450,
    createdAt: '2026-10-11T10:15:00',
    status: 'NEW_LEAD'
  }
];

// ============================================================================
// 12. CONSOLIDATED DEFAULT INITIAL STORE OBJECT
// ============================================================================
export const DEFAULT_STORE = {
  warehouses: INITIAL_WAREHOUSES,
  shops: INITIAL_SHOPS,
  employees: INITIAL_EMPLOYEES,
  societies: INITIAL_SOCIETIES,
  categories: INITIAL_CATEGORIES,
  units: INITIAL_UNITS,
  products: INITIAL_PRODUCTS,
  orders: INITIAL_ORDERS,
  withdrawals: INITIAL_WITHDRAWALS,
  procurementLogs: INITIAL_PROCUREMENT_LOGS,
  societyRequests: INITIAL_SOCIETY_REQUESTS
};
