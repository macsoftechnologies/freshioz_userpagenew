import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Building2, 
  Leaf, 
  Clock, 
  ShieldCheck, 
  Truck, 
  Coins, 
  Phone, 
  Mail, 
  MapPin, 
  ArrowRight,
  Package
} from 'lucide-react';
import FreshiozLogo from '../common/FreshiozLogo';
import { useStore } from '../../context/StoreContext';

export default function AppFooter() {
  const { setIsSocietyRequestModalOpen, cutoffInfo, activeUser } = useStore();

  return (
    <footer className="freshioz-footer-wrap">
      {/* 4 Feature Value Pillars */}
      <div className="footer-pillars-strip">
        <div className="footer-pillars-inner">
          <div className="pillar-item">
            <div className="pillar-icon-box">
              <Leaf size={22} color="#78B159" />
            </div>
            <div>
              <div className="pillar-title">100% Dawn Harvest</div>
              <div className="pillar-desc">Procured fresh at 4:00 AM from APMC mandis & farmers</div>
            </div>
          </div>

          <div className="pillar-item">
            <div className="pillar-icon-box">
              <Clock size={22} color="#F28E14" />
            </div>
            <div>
              <div className="pillar-title">Next-Day 7:00 AM Delivery</div>
              <div className="pillar-desc">Order before {cutoffInfo.cutoffTimeStr} & receive at your society lobby</div>
            </div>
          </div>

          <div className="pillar-item">
            <div className="pillar-icon-box">
              <Coins size={22} color="#DE8821" />
            </div>
            <div>
              <div className="pillar-title">Society Fund Cashback</div>
              <div className="pillar-desc">Up to 4% commission credited to your apartment association</div>
            </div>
          </div>

          <div className="pillar-item">
            <div className="pillar-icon-box">
              <Package size={22} color="#234B3C" />
            </div>
            <div>
              <div className="pillar-title">Wholesale Crate Rates</div>
              <div className="pillar-desc">Bulk rates for hostel messes, canteens & group buying</div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Links & Information */}
      <div className="footer-main-body">
        <div className="footer-main-inner">
          {/* Column 1: Brand & About */}
          <div className="footer-col brand-col">
            <div className="footer-logo-badge-card">
              <FreshiozLogo height={52} showTagline={true} />
            </div>
            <p className="footer-brand-desc">
              Hyper-local community farm-fresh vegetable and fruit platform built specifically for Apartments, Gated Communities, and Hostels with aggregated next-day morning delivery.
            </p>
            <div className="footer-contact-item">
              <Mail size={15} color="#78B159" />
              <span>support@freshioz.com</span>
            </div>
            <div className="footer-contact-item">
              <Phone size={15} color="#78B159" />
              <span>+91 98450 11000 (06:00 AM – 09:00 PM)</span>
            </div>
            <div className="footer-contact-item">
              <MapPin size={15} color="#78B159" />
              <span>Direct APMC Farm Mandis & Regional Hubs, Bengaluru</span>
            </div>
          </div>

          {/* Column 2: Farm Categories */}
          <div className="footer-col">
            <h4 className="footer-heading">Fresh Harvest</h4>
            <ul className="footer-nav-list">
              <li><Link to="/catalog?cat=VEGETABLES">Daily Farm Vegetables</Link></li>
              <li><Link to="/catalog?cat=FRUITS">Fresh Orchard Fruits</Link></li>
              <li><Link to="/catalog?cat=LEAFY_GREENS">Leafy Greens & Fresh Herbs</Link></li>
              <li><Link to="/catalog?cat=EXOTIC">Hydroponic & Exotic Salads</Link></li>
              <li><Link to="/wholesale">Wholesale Crates (20kg Crates)</Link></li>
              <li><Link to="/wholesale">Bulk Sacks (25kg Jute/Mesh Sacks)</Link></li>
            </ul>
          </div>

          {/* Column 3: Community & Societies */}
          <div className="footer-col">
            <h4 className="footer-heading">Societies & Hostels</h4>
            <ul className="footer-nav-list">
              {!activeUser && <li><Link to="/society-portal">Society Partner Portal</Link></li>}
              <li>
                <button
                  type="button"
                  onClick={() => setIsSocietyRequestModalOpen(true)}
                  style={{ background: 'none', border: 'none', padding: 0, color: 'inherit', font: 'inherit', cursor: 'pointer', textAlign: 'left' }}
                >
                  Request Your Apartment / Hostel
                </button>
              </li>
              {!activeUser && <li><Link to="/society-portal">Association Maintenance Fund</Link></li>}
              <li><Link to="/wholesale">Hostel Mess Bulk Supply</Link></li>
              <li><Link to="/profile">My Community Orders</Link></li>
            </ul>
          </div>

          {/* Column 4: Morning Fresh Promise & Support */}
          <div className="footer-col">
            <h4 className="footer-heading">Morning Fresh Promise</h4>
            <div style={{ fontSize: '12.5px', color: '#BDE2CB', lineHeight: '1.6', marginBottom: '10px' }}>
              <strong style={{ color: '#FFF' }}>🌾 Multi-Mandi Direct Sourcing:</strong>
              <div>Fresh dawn produce procured across regional APMC yards directly to your community.</div>
            </div>
            <div style={{ fontSize: '12.5px', color: '#BDE2CB', lineHeight: '1.6', marginBottom: '14px' }}>
              <strong style={{ color: '#FFF' }}>🚚 Society Drop Desk Slot:</strong>
              <div>Arrives by <strong>06:30 AM – 08:30 AM</strong> every morning without delivery delays.</div>
            </div>
            <div style={{
              background: 'rgba(255, 255, 255, 0.08)',
              border: '1px solid rgba(255, 255, 255, 0.16)',
              borderRadius: '10px',
              padding: '10px 12px',
              fontSize: '11.5px',
              color: '#FFD494',
              lineHeight: '1.45'
            }}>
              <div style={{ fontWeight: 800, color: '#78B159', marginBottom: '3px' }}>
                🛡️ Zero Stale Inventory Guarantee
              </div>
              <div>Daily cut-off: <strong>{cutoffInfo.cutoffTimeStr}</strong> for tomorrow morning’s farm-fresh dispatch.</div>
            </div>
          </div>
        </div>
      </div>

      {/* Sub-Footer Copyright & Badges */}
      <div className="footer-bottom-bar">
        <div className="footer-bottom-inner">
          <div className="copyright-text">
            © 2026 Freshioz Technologies Pvt Ltd. All rights reserved. • Next-Day Farm-to-Society Produce Network.
          </div>
          <div className="footer-badges">
            <span className="badge-tag">🌿 100% Wax-Free</span>
            <span className="badge-tag">🔬 FSSAI Compliant</span>
            <span className="badge-tag">🏢 Society Partner Verified</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
