import React from 'react';
import { Clock, Sparkles } from 'lucide-react';
import { useStore } from '../../context/StoreContext';

export default function AnnouncementBar() {
  const { cutoffInfo, selectedSociety } = useStore();

  return (
    <div className="cutoff-announcement-bar">
      <div className="cutoff-badge-pill">
        <Clock size={13} />
        {cutoffInfo.isPastCutoff ? 'Next Slot' : `Cutoff: ${cutoffInfo.cutoffTimeStr}`}
      </div>
      <div className="cutoff-text">
        {cutoffInfo.isPastCutoff ? (
          <span>
            Orders placed now are scheduled for <strong>{cutoffInfo.formattedDeliveryDate} (Day After Tomorrow)</strong> to {selectedSociety?.name || 'your society'}.
          </span>
        ) : (
          <span>
            Order within <strong>{cutoffInfo.hoursRemaining}h {cutoffInfo.minutesRemaining}m</strong> for <strong>Tomorrow Morning ({cutoffInfo.formattedDeliveryDate})</strong> delivery!
          </span>
        )}
      </div>
      <div style={{ display: 'none', alignItems: 'center', gap: '4px', color: '#78B159', fontSize: '12px' }}>
        <Sparkles size={13} /> 100% Farm-to-Fork Direct
      </div>
    </div>
  );
}
